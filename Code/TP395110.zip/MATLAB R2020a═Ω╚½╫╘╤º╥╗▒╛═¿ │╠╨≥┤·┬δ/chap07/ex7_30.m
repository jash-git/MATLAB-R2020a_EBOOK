syms t w real;
f=sym('cos(t)*sin(t)')
f =
	cos(t)*sin(t)
fourier(f,t,w)
