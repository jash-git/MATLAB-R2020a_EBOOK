clear
x=0.5;
syms y;
whos
