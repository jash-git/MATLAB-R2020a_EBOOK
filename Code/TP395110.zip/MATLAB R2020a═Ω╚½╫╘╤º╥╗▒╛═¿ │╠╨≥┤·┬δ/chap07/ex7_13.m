syms x y z u v w
f=sym('3*x^2+2*y+z+u^-1+v^-2+w^-3')
findsym(f)
