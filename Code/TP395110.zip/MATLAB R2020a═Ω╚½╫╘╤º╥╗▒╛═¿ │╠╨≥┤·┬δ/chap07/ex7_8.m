syms a b c d;
A=sym('[a,b;c,d]')
A =
	 [ a, b]
	 [ c, d]
R1=A'
