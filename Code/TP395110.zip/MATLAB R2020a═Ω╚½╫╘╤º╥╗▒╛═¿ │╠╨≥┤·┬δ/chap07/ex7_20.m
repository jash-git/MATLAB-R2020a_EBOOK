sym x;
f1=sym('(x^3-1)/(x-1)')
f1 =
	(x^3 - 1)/(x - 1)
simplify(f1)
