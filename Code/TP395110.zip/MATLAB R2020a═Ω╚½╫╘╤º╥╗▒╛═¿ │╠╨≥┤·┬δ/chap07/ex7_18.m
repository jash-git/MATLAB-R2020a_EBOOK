syms x y;
f1=sym('x^3-6*x^2+11*x-6')
f1 =
	x^3 - 6*x^2 + 11*x �C 6
horner(f1)
