sym x;
f=sym('a*x^3+b*x^2+c*x+d+e*x^-1+f*x^-2+g*x^-3')
pretty(f)
