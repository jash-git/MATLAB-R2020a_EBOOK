syms n;
f=sym('n^3+n^2+n+1')
f =
	n^3 + n^2 + n + 1
ztrans(f)
