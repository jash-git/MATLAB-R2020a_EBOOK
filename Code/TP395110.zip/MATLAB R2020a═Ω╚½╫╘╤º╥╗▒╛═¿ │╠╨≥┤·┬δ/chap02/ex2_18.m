C = {'x',[1;3;6];10,pi}
whos C
