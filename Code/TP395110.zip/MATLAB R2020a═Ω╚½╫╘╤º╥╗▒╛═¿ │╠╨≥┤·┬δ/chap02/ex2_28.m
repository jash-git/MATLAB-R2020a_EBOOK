schedulemap('Saturday') = 'public elective course'
keys(schedulemap)
values(schedulemap)
