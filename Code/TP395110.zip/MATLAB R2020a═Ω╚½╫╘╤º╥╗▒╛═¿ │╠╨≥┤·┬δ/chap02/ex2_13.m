 Student.Name='Sam';
 Student.Grade=6;
 Student.Subject={'Chinese','Math','English'};
 Student.Result={99,99,99};
