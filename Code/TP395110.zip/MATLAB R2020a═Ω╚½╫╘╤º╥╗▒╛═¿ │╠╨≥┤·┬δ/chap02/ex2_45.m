A = rand(4,3)
x = A(2,2)
y = A(4,3)
