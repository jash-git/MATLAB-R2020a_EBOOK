clear
A = [2 3;10 7]
isnumeric(A)
isfloat(A)
islogical(A)
B = ['matlab';'course']
isstruct(B)
ischar(B)