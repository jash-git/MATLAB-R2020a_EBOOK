Str_a='How are you?', Str_b='I don''t know.', Str_c = strcat( Str_a, Str_b)
 Str_mat1 = ['U r a man.'; 'I''m a pen.'], Str_mat2 = {'July';'August';'September';}