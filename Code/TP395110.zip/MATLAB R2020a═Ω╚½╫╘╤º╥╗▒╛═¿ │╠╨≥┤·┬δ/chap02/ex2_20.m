C = {3,[4 7;6 6;80 9],'string';sin(pi/8),3>10,'code'}
unitVal_1 = C(2,2)
class(unitVal_1)
unitVal_2 = C{2,2}
class(unitVal_2)
