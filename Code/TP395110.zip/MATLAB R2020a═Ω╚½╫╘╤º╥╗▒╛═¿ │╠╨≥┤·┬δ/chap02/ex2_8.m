String ='Every good boy does fun.';
U =String(7:10)
