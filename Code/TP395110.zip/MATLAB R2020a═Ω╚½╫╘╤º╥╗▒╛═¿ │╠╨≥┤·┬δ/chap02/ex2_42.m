Mat = magic(2);
TrueorFalse = [isnumeric(Mat) isinteger(Mat) isreal(Mat) isfloat(Mat)]
