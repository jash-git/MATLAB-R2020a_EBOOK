rad=2.5;  area=pi*rad ^2;
string =[' A circle of radius '  num2str(rad)  ' has an area of ' num2str(area)  ' . ' ] ;
disp(string)