Matrix = magic( 6 ) , Submatrix = Matrix( 2:3, 3:6 ), Array =
           Matrix( [7:10 26:31] )
