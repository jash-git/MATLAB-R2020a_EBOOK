a = cell(2,2)
b = cell(1)
whos
