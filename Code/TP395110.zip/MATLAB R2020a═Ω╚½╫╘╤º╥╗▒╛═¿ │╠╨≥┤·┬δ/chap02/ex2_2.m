format long
eps(3)
