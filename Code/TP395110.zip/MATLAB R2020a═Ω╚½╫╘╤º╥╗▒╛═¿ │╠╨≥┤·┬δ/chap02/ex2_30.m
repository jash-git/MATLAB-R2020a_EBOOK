schedulemap('Monday')
schedulemap('Monday') = 'english';
keys(schedulemap)
values(schedulemap)
