C = {ones(3),'Hello, World',zeros(5),[20,4,6]}
C{1,4} = []
