clear
a=uint32(120);b=single(22.809);c=73.226;
ab=a*b
ac=a*c
bc=b*c
str='hello'
newstr=str-44.3
whos