remove(schedulemap,'Saturday');
schedulemap('Sunday') = 'MBA';
keys(schedulemap)
values(schedulemap)
