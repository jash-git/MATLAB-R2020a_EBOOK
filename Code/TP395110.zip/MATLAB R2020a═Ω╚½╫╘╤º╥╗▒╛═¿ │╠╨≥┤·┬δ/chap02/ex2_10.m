U ='Hello,';
V =' world!';
W = [U V]
