 F_Handlea=@exp
 
 F_Handleb=@log
 
 functions(F_Handlea )