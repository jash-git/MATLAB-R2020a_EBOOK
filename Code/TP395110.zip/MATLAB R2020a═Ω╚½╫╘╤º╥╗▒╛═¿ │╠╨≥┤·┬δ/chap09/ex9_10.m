function y=mythe(x)
x=x+2;
y=x.^2;
