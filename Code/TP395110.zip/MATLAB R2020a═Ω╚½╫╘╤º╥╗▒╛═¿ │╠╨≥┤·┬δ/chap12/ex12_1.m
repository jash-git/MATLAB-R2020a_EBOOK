x = fminbnd(@cos,0,2*pi)
x =
    10.1416
y = cos(x)
