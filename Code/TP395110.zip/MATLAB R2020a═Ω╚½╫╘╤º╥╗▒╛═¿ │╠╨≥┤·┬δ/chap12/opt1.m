function f = opt1(x)
f = -(3-2*x).^2 * x;
