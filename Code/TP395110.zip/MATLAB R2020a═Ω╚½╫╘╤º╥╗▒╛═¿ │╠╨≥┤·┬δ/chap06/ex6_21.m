clear all
syms x;
f=(3*x^2)/(3*x^2-2*x+1);
z=limit(f,x,1)
