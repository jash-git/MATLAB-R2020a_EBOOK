clear all
syms x;
f=sin(sin(x))/x-1;
z=limit(f,x,0)
