x = [];
for n = 1:1:10
    for k = 1:1:4
        x(n,k) = sin((n*k*pi)/360);
    end
end
x
