clear
n = input('Enter the value of''n'':');
x = input('Enter the value of''x'':');
switch(n)
     case 1
     errordlg('����');
     case 2
     y=log2(x);
     case exp(1)
     y=log(x);
     case 10
     y=log10(x);
    otherwise
     y=log10(x)/log10(n);
end
disp(y)
