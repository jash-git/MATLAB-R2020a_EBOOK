Array = 1:5;
String = '[Array*2; Array/2; 2.^Array]';
Output = eval(String)
