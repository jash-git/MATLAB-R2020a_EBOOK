inmem
ans = 
    'MATLABrc'
    'pathdef'
    'userpath'
    'ispc'
    'filesep'
    'pwd'
    'usejava'
    'initializeMATLABRoot'
    'opaque.char'
'hgrc'
��
    'helpProcess.getDemoTopic'
    'helpProcess.displayHelp'

    
subplot(1,3,1), spirallength(2,2,1)
subplot(1,3,2), spirallength(2,2,1,'Marker','o')
subplot(1,3,3), spirallength(2,2,1,'r--', 'LineWidth',2)
