clear all
format short;
A = linspace(1,100)
B = linspace(1,36,12)
C= linspace(1,36,1)
