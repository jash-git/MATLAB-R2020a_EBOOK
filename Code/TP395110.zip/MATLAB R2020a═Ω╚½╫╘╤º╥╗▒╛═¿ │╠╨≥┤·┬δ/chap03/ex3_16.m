clear all
B=rand(3)
C=rand([3,4])
D=rand(size(C))
