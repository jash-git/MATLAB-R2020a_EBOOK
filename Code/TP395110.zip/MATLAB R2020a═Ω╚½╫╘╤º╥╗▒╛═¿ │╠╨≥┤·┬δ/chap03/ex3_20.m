clear all
A=vander([1 2 3 4]) 
B=vander([1;2;3;4]) 
C=vander(1:.5:3) 
