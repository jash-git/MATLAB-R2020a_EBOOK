clear all
A=[1 2 3;3 4 5;7 8 9;8 7 9;0 2 8];
B=magic(5);
subspace(A,B)
