load clown
BW = roicolor(X,10,20);
subplot(121),imshow(X,map)
subplot(122),imshow(BW)
