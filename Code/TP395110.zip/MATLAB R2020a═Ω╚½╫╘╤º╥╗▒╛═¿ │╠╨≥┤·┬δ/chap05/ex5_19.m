ezplot('sin(x)^2+4*cos(y)^2=4',[-5 5 -1 1]);
axis square
