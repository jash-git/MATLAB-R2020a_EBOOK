n1 = [normrnd(1:6,1./(1:6)); normrnd(1:6,1./(1:6)); normrnd(1:6,1./(1:6));]
n2 = normrnd(0,1,[1 5])
n3 = normrnd(0,1,[5 5])
n4 = normrnd([1 2 3;4 5 6],0.1,2,3)
