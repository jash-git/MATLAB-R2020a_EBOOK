T=ceil(5*rand(1,10))
table = tabulate(T)
