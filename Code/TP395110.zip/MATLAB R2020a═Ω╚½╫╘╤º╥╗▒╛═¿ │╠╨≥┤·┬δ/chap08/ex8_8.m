A=rand(5)
Y1=sort(A) 
Y2=sortrows(A)
Y3=range(A)
