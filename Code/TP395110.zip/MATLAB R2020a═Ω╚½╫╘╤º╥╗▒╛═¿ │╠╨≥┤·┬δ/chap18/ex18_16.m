[fid,message]=fopen('tan.m','r')
 if fid==-1
disp(message)
end
