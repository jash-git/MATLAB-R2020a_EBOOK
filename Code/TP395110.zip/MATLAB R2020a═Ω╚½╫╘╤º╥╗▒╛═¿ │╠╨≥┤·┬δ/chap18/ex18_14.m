[fid1,messange1]=fopen('tan.m','r')
[fid2,messange2]=fopen('sin.m','r')
[fid3,messange3]=fopen('cos.m','r')
[fid4,messange4]=fopen('sintan.m','r')
