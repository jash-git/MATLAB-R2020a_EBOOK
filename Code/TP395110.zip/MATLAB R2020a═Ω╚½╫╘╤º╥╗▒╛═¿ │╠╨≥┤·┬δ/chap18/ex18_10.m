[s,mess,messid]=copyfile('t.m',��
'E:\ug\written book\matlab\M�ļ�\chap18\create\t.m')  %copy t.m
