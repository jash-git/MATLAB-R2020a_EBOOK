clear all
clc
csvwrite('csvlist.dat',m,0,2)
type csvlist.dat
