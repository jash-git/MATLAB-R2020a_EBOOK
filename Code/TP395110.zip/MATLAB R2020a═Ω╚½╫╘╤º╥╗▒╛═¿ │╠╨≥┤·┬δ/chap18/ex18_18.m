n1=ones(10);
n1=ones(12);
n2=zeros(25);
n3=rand;
save nmat n*
