[fid,message]=fopen('filename','r');
 if fid==-1
disp(message);
end
