clear all;
A=rand(4,4)
B=inv(A)
pause