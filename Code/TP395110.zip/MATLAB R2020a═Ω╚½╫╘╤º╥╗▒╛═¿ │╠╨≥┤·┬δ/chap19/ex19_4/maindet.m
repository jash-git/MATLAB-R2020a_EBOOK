function maindet
mat_feat('my_det')
