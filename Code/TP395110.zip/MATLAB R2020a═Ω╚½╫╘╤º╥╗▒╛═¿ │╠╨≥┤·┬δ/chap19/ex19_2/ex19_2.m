clear all;
clc;
A=[-2,0,4;1,2,3;-3,2,0]
[m,n,p]=myfuntion(A);